function 여행하다() {
    console.log("1. 돈을 마련한다")
    console.log("2. 교통편과 숙박장소 예매한다")
    console.log("3. 여행에서 계획대로 즐긴다")
}
function 쉬다(){
    console.log("1. 눕는다")
    console.log("2. 눈을 감는다")
    console.log("3. 명상한다")
}