 //함수는 여러절차가 있는 처리를 이름을 부여하여 기능을 정의!
      //function
      function 빨래하다() {
        console.log("1. 먼지를 털자.")
        console.log("2. 물에 집어 넣는다.")
        console.log("3. 비누를 바른다.")
        console.log("4. 오물조물 비빈다.")
        console.log("5. 물에 여러번 헹군다.")
        console.log("6. 짠다.")
        console.log("7. 넌다.")
     }

     //청소하다에 대한 함수정의해서 사용해보세요.!
     function 청소하다() {
        console.log("1. 로봇청소기를 돌리다.")
        console.log("2. 물걸레로 닦다.")
     }